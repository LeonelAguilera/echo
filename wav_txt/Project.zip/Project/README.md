# Grp4Project

An FPGA/VHDL project playing audio for the Terasic DE2-115 board.  

---

## Project Structure

```

src/              # VHDL source files
top.vhdl          # Top-level entity, connects all components
example.vhdl      # Simple reference component
tb/               # Testbenches

````

New components should be added to `src/` and connected through `top.vhdl`.

---

## Using Git and GitHub

### What is Git?
[Git](https://git-scm.com/) is a distributed version control system used to track changes in code and collaborate with others.  

Recommended reading: [Pro Git book](https://git-scm.com/book/en/v2)

---

### Setup

1. Install Git: [Download Git](https://git-scm.com/downloads)  
2. Configure SSH for GitHub: [Guide](https://docs.github.com/en/authentication/connecting-to-github-with-ssh)

---

### Clone the Repository

```bash
git clone git@github.com:Neznauy/Grp4Project.git
````

---

### Typical Workflow

1. Get the latest changes

   ```bash
   git pull
   ```

2. Create a new branch

   ```bash
   git checkout -b my_feature_branch
   ```

3. Stage and commit your work

   ```bash
   git add <filename>   # stage a specific file
   git add .            # stage all changes
   git status           # check staged files
   git commit -m "Meaningful commit message"
   ```

4. Push your branch to GitHub

   ```bash
   git push origin my_feature_branch
   ```

Do not push directly to `main`.
Always create a branch and then a pull request.

---

### Creating a Pull Request

1. Go to the Pull requests tab on GitHub.
2. Click "New pull request" green button.
3. In the "compare" dropdown, select your branch.
4. Click "Create pull request" green button.
5. Wait for CI checks to finish:

   * The CI runs GHDL to check that the VHDL code compiles.
   * If successful, the check will show as green.
6. Change green button to "Squash and merge" and click it to add your changes to `main`.

---
